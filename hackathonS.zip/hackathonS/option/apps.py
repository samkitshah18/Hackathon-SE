from django.apps import AppConfig


class OptionConfig(AppConfig):
    name = 'option'
