from django.urls import path
from .import views
from .views import PostListView, PostDetailView, PostCreateView, PostUpdateView, PostDeleteView, UserPostListView,AnswerCreateView
urlpatterns = [
    path('', PostListView.as_view(), name='question-home'),
    path('user/<str:username>', UserPostListView.as_view(), name='user-posts'),
    path('post/<int:pk>/update/', PostUpdateView.as_view(), name='question-update'),
    path('post/<int:pk>/delete/', PostDeleteView.as_view(), name='question-delete'),
    path('post/new/', PostCreateView.as_view(), name='question-create'),
    path('post/<int:pk>/', PostDetailView.as_view(), name='question-detail'),
    path('about/', views.about,name='question-about'),
    path('post/<int:pk>/addanswer',AnswerCreateView.as_view(),name='add-answer')
]
