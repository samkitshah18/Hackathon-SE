from django.apps import AppConfig


class StudyConfig(AppConfig):
    name = 'study'
