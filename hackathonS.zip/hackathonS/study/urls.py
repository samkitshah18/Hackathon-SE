from django.contrib import admin
from django.urls import path,include
from .import views
from .views import UploadCreateView
from django.conf import settings

urlpatterns = [
    path('', views.studyhome, name='study-home'),
    path('create/', views.upload, name='upload'),
    path('all/', views.book_list, name='book-list'),
    path('create/upload', UploadCreateView.as_view(), name='upload-book'),
    path('books/<int:pk>/', views.delete_book, name='delete_book'),
]